// Nome: Marcos André Silveira 
// Matrícula : UC12029761
// Curso: Engenharia Civil
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{   
    int hora, minutos, segundos;
    printf("Digite o numero inteiro de horas: ");
    scanf("%d", &hora);
    minutos = hora * 60;
    segundos = 60 * minutos;

    printf("%d hora(s) e igual a: ", hora);
    printf("%d minutos", minutos);
    printf(" e %d segundos", segundos);
    return 0;
}

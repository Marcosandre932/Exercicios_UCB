// Nome: Marcos André Silveira 
// Matrícula : UC12029761
// Curso: Engenharia Civil
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{   
    float nota_1, nota_2, media;
    
    while (1)
    {
        printf("Digite a nota 1: ");
        scanf("%f", &nota_1);
        if (nota_1 <= 10 && nota_1 >= 0)
        {
            break;
        }
        printf("\nA nota deve ser entre 0 e 10");
        
    }
    while (1)
    {
        printf("Digite a nota 2: ");
        scanf("%f", &nota_2);
        if (nota_2 <= 10 && nota_2 >= 0)
        {
            break;
        }
        printf("\nA nota deve ser entre 0 e 10");
        
    }
    
    media = (nota_1 * 0.35) + (nota_2 * 0.75);
    printf("A media e: %.2f", media);
    return 0;
}

// Nome: Marcos André Silveira 
// Matrícula : UC12029761
// Curso: Engenharia Civil
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{   
    float a, b, c, media;
    printf("Digite o primeiro numero: ");
    scanf("%f", &a);
    printf("Digite o segundo numero: ");
    scanf("%f", &b);
    printf("Digite o terceiro numero: ");
    scanf("%f", &c);

    media = a + b + c;
    media = media / 3;

    printf("A media e: %.2f", media);
    
    return 0;
}

// Nome: Marcos André Silveira 
// Matrícula : UC12029761
// Curso: Engenharia Civil
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{   
    int qtd_fio, qtd_rolo, qtd_avulso;
    printf("Digite a quantidade de fio: ");
    scanf("%d", &qtd_fio);
    
    if (qtd_fio < 50)
    {
        printf("Precisa de %d metro(s) de fio avulso", qtd_fio);
    } 
    else
    {
        qtd_rolo = qtd_fio / 50;
        qtd_avulso = qtd_rolo * 50;
        qtd_avulso = qtd_fio - qtd_avulso;
        printf("\nE necessario %d rolo(s)", qtd_rolo);
        printf("\nE necessario %d metro(s) de fio avulso", qtd_avulso);
    }
    
    return 0;
}

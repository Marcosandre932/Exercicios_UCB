// Nome: Marcos André Silveira 
// Matrícula : UC12029761
// Curso: Engenharia Civil
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{   
    float area, raio;
    printf("Digite o raio do circulo: ");
    scanf("%f", &raio);
    
    area = 3.14 * (raio * raio);

    printf("A ærea de %f igual a %.2f ", raio, area);
    
    return 0;
}

// Nome: Marcos André Silveira 
// Matrícula : UC12029761
// Curso: Engenharia Civil
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{   
    float valor_hora, matricula, salario;
    int qtd_hora_trabalhada;
    char sexo, nome[20];

    printf("Digite: ");
    printf("\n\to nome do funcionario: ");
    fgets(nome, 20, stdin);
    printf("\to sexo do funcionario, F ou M: ");
    scanf("%c", &sexo);
    printf("\ta matricula do funcionario: ");
    scanf("%f", &matricula);
    printf("\to numero de horas trabalhadas: ");
    scanf("%d", &qtd_hora_trabalhada);
    printf("\to valor por hora trabalhada: ");
    scanf("%f", &valor_hora);

    salario = qtd_hora_trabalhada * valor_hora;

    printf("_______________");
    printf("\nNome: %c - Sexo: %c - Matricula - %.0f", nome, sexo, matricula);
    printf("\n|- Valor por hora trabalhada: %.2f - Horas trabalhadas: %d", valor_hora, qtd_hora_trabalhada);
    printf("\n|- Salario: R$: %.2f", salario);
    return 0;
}

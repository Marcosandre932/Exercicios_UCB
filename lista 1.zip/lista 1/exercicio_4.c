// Nome: Marcos André Silveira 
// Matrícula : UC12029761
// Curso: Engenharia Civil
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{   
    int a, b, quociente, resto;
    printf("Digite o primeiro numero: ");
    scanf("%d", &a);
    printf("Digite o segundo numero: ");
    scanf("%d", &b);


    quociente = a / b;
    resto = a % b;

    printf("\nO quociente e: %d", quociente);
    printf("\nO resto e: %d", resto);
    
    return 0;
}
